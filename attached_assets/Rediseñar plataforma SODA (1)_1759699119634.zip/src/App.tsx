import { useState } from "react";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { DashboardStats } from "./components/DashboardStats";
import { RecentInvoices } from "./components/RecentInvoices";
import { QuickActions } from "./components/QuickActions";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const chartData = [
  { name: 'Ene', amount: 18500000 },
  { name: 'Feb', amount: 22000000 },
  { name: 'Mar', amount: 19800000 },
  { name: 'Abr', amount: 24200000 },
  { name: 'May', amount: 21600000 },
  { name: 'Jun', amount: 26400000 },
];

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      
      <div className="flex-1 flex flex-col lg:ml-0">
        <Header setSidebarOpen={setSidebarOpen} />
        
        <main className="flex-1 p-4 md:p-6">
          {/* Page Header */}
          <div className="mb-6 md:mb-8">
            <h1 className="mb-2">Dashboard</h1>
            <p className="text-gray-600">Vista general de tu cartera de arriendos</p>
          </div>

          {/* Stats Cards */}
          <DashboardStats />

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
            <div className="xl:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Ingresos por Mes</CardTitle>
                  <p className="text-sm text-gray-500">
                    Evolución de ingresos por alquileres
                  </p>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250} className="md:!h-[300px]">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="name" 
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis 
                        tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip 
                        formatter={(value) => [`${(value as number).toLocaleString()}`, 'Ingresos']}
                        labelFormatter={(label) => `Mes: ${label}`}
                      />
                      <Bar dataKey="amount" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <div>
              <QuickActions />
            </div>
          </div>

          {/* Recent Invoices */}
          <RecentInvoices />
        </main>
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}