import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "./ui/table";
import { MoreHorizontal, Eye, FileText, Send } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { InvoiceDetailModal } from "./modals/InvoiceDetailModal";

const invoices = [
  {
    number: "FAC-802",
    tenant: "Ismael González",
    property: "Apartamento 101 - Zona Rosa",
    total: "$ 7.600.000",
    status: "paid",
    dueDate: "15 Dic 2024",
    issueDate: "1 Dic 2024",
    period: "Diciembre 2024",
    description: "Alquiler mensual incluyendo administración y parqueadero"
  },
  {
    number: "CNT-001-OCR-698877",
    tenant: "Antonio José",
    property: "Apartamento 202 - El Poblado",
    total: "$ 4.423.243,01",
    status: "sent",
    dueDate: "20 Dic 2024",
    issueDate: "5 Dic 2024",
    period: "Diciembre 2024",
    description: "Alquiler mensual y servicios adicionales"
  },
  {
    number: "CNT-001-OCR-218968",
    tenant: "Antonio José",
    property: "Casa 301 - Laureles",
    total: "$ 4.423.243,01",
    status: "sent",
    dueDate: "25 Dic 2024",
    issueDate: "10 Dic 2024",
    period: "Diciembre 2024",
    description: "Alquiler mensual con servicios incluidos"
  },
  {
    number: "CNT-001-001",
    tenant: "Antonio José",
    property: "Apartamento 202 - El Poblado",
    total: "$ 5.600.000",
    status: "sent",
    dueDate: "30 Dic 2024",
    issueDate: "15 Dic 2024",
    period: "Enero 2025",
    description: "Alquiler mensual anticipado"
  },
  {
    number: "Env-001",
    tenant: "Antonio José",
    property: "Apartamento 101 - Zona Rosa",
    total: "$ 500.000",
    status: "paid",
    dueDate: "10 Dic 2024",
    issueDate: "1 Dic 2024",
    period: "Diciembre 2024",
    description: "Servicios adicionales y mantenimiento"
  }
];

function getStatusBadge(status: string) {
  switch (status) {
    case "paid":
      return (
        <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
          Pagada
        </Badge>
      );
    case "sent":
      return (
        <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
          Enviada
        </Badge>
      );
    case "overdue":
      return (
        <Badge variant="destructive">
          Vencida
        </Badge>
      );
    default:
      return (
        <Badge variant="secondary">
          Borrador
        </Badge>
      );
  }
}

export function RecentInvoices() {
  const [selectedInvoice, setSelectedInvoice] = useState<typeof invoices[0] | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const viewInvoiceDetail = (invoice: typeof invoices[0]) => {
    setSelectedInvoice(invoice);
    setIsDetailModalOpen(true);
  };

  return (
    <>
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Facturas Recientes</CardTitle>
            <p className="text-sm text-gray-500 mt-1">
              Últimas facturas emitidas en el sistema
            </p>
          </div>
          <Button variant="outline" size="sm" className="self-start sm:self-auto">
            Ver todas
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Desktop Table */}
        <div className="hidden md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número</TableHead>
                <TableHead>Inquilino</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Vencimiento</TableHead>
                <TableHead className="w-[70px]">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      <span className="text-sm truncate">{invoice.number}</span>
                    </div>
                  </TableCell>
                  <TableCell className="truncate">{invoice.tenant}</TableCell>
                  <TableCell className="truncate">{invoice.total}</TableCell>
                  <TableCell>
                    {getStatusBadge(invoice.status)}
                  </TableCell>
                  <TableCell className="text-gray-600">{invoice.dueDate}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => viewInvoiceDetail(invoice)}>
                          <Eye className="mr-2 h-4 w-4" />
                          Ver detalle
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Send className="mr-2 h-4 w-4" />
                          Reenviar
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <FileText className="mr-2 h-4 w-4" />
                          Descargar PDF
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Mobile Cards */}
        <div className="md:hidden space-y-4">
          {invoices.map((invoice, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <FileText className="h-4 w-4 text-gray-400 flex-shrink-0" />
                  <span className="text-sm">{invoice.number}</span>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Eye className="mr-2 h-4 w-4" />
                      Ver detalle
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => viewInvoiceDetail(invoice)}>
                      <Eye className="mr-2 h-4 w-4" />
                      Ver detalle
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Send className="mr-2 h-4 w-4" />
                      Reenviar
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <FileText className="mr-2 h-4 w-4" />
                      Descargar PDF
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Inquilino:</span>
                  <span className="text-sm truncate ml-2">{invoice.tenant}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Total:</span>
                  <span className="text-sm">{invoice.total}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Estado:</span>
                  {getStatusBadge(invoice.status)}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Vencimiento:</span>
                  <span className="text-sm text-gray-600">{invoice.dueDate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>

    {/* Invoice Detail Modal */}
    <InvoiceDetailModal
      open={isDetailModalOpen}
      onOpenChange={setIsDetailModalOpen}
      invoice={selectedInvoice}
    />
    </>
  );
}