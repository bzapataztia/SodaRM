import { 
  Home, 
  FileText, 
  Receipt, 
  CreditCard, 
  Building, 
  Users, 
  Settings,
  BarChart3,
  X
} from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from './figma/ImageWithFallback';
import sodaLogo from "figma:asset/a351b7e532925504737c0ccec83151ab99453f3b.png";

const navigation = [
  { name: "Dashboard", icon: Home, current: true },
  { name: "Contratos", icon: FileText, current: false },
  { name: "Facturas", icon: Receipt, current: false, badge: "5" },
  { name: "Pagos", icon: CreditCard, current: false },
  { name: "Propiedades", icon: Building, current: false },
  { name: "Contactos", icon: Users, current: false },
];

const adminNavigation = [
  { name: "Asignaciones", icon: BarChart3, current: false },
  { name: "Pólizas", icon: FileText, current: false },
];

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export function Sidebar({ sidebarOpen, setSidebarOpen }: SidebarProps) {
  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex bg-white w-64 min-h-screen border-r border-gray-200 flex-col fixed left-0 top-0 z-30">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar */}
      <div className={`lg:hidden fixed left-0 top-0 z-50 bg-white w-64 min-h-screen border-r border-gray-200 flex flex-col transform transition-transform duration-300 ease-in-out ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        {/* Close button for mobile */}
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ImageWithFallback 
              src={sodaLogo} 
              alt="SODA Logo" 
              className="h-8 w-auto"
            />
            <div>
              <h2 className="text-sm text-gray-500">Rental Manager</h2>
              <p className="text-xs text-gray-400">Inmobiliaria SAS</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1">
          <SidebarContent />
        </div>
      </div>
    </>
  );
}

function SidebarContent() {
  return (
    <>
      {/* Logo - Only for desktop */}
      <div className="hidden lg:block p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <ImageWithFallback 
            src={sodaLogo} 
            alt="SODA Logo" 
            className="h-8 w-auto"
          />
          <div>
            <h2 className="text-sm text-gray-500">Rental Manager</h2>
            <p className="text-xs text-gray-400">Inmobiliaria SAS</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-1">
        <div className="space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.name}
                variant={item.current ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  item.current 
                    ? "bg-purple-50 text-purple-700 border-purple-200" 
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <Icon className="mr-3 h-4 w-4 flex-shrink-0" />
                <span className="truncate">{item.name}</span>
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto bg-purple-100 text-purple-700 flex-shrink-0">
                    {item.badge}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>

        <div className="pt-6">
          <h3 className="px-3 text-xs uppercase tracking-wider text-gray-500 mb-3">
            Administración
          </h3>
          <div className="space-y-1">
            {adminNavigation.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.name}
                  variant="ghost"
                  className="w-full justify-start text-gray-700 hover:bg-gray-50"
                >
                  <Icon className="mr-3 h-4 w-4 flex-shrink-0" />
                  <span className="truncate">{item.name}</span>
                </Button>
              );
            })}
          </div>
        </div>

        <div className="pt-6">
          <h3 className="px-3 text-xs uppercase tracking-wider text-gray-500 mb-3">
            Configuración
          </h3>
          <div className="space-y-1">
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:bg-gray-50">
              <Settings className="mr-3 h-4 w-4 flex-shrink-0" />
              <span className="truncate">Ajustes</span>
            </Button>
          </div>
        </div>
      </nav>

      {/* Plan info */}
      <div className="p-4 border-t border-gray-200">
        <div className="bg-purple-50 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-purple-700">Plan Trial</span>
            <Badge variant="outline" className="text-xs">
              7/10
            </Badge>
          </div>
          <div className="w-full bg-purple-200 rounded-full h-2 mb-2">
            <div className="bg-purple-600 h-2 rounded-full w-3/4"></div>
          </div>
          <Button size="sm" className="w-full bg-purple-600 hover:bg-purple-700">
            Actualizar plan
          </Button>
        </div>
      </div>
    </>
  );
}