import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Building, MapPin, Home, DollarSign } from "lucide-react";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";

interface AddPropertyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddPropertyModal({ open, onOpenChange }: AddPropertyModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    type: "",
    address: "",
    city: "",
    neighborhood: "",
    bedrooms: "",
    bathrooms: "",
    area: "",
    rentPrice: "",
    deposit: "",
    description: "",
    status: "available"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Adding property:", formData);
    onOpenChange(false);
    // Reset form
    setFormData({
      name: "",
      type: "",
      address: "",
      city: "",
      neighborhood: "",
      bedrooms: "",
      bathrooms: "",
      area: "",
      rentPrice: "",
      deposit: "",
      description: "",
      status: "available"
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="bg-green-100 p-2 rounded-lg">
              <Building className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <DialogTitle>Agregar Nueva Propiedad</DialogTitle>
              <DialogDescription>
                Registrar una nueva propiedad en tu cartera de arriendos
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información básica */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Home className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Información Básica</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre/Identificación</Label>
                <Input
                  id="name"
                  placeholder="Ej: Apartamento 101"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Propiedad</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="apartment">Apartamento</SelectItem>
                    <SelectItem value="house">Casa</SelectItem>
                    <SelectItem value="studio">Estudio</SelectItem>
                    <SelectItem value="penthouse">Penthouse</SelectItem>
                    <SelectItem value="office">Oficina</SelectItem>
                    <SelectItem value="commercial">Local Comercial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Estado</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger className="md:w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Disponible</SelectItem>
                  <SelectItem value="occupied">Ocupado</SelectItem>
                  <SelectItem value="maintenance">En Mantenimiento</SelectItem>
                  <SelectItem value="inactive">Inactivo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          {/* Ubicación */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Ubicación</h3>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Dirección Completa</Label>
                <Input
                  id="address"
                  placeholder="Calle 123 #45-67"
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Ciudad</Label>
                  <Input
                    id="city"
                    placeholder="Medellín"
                    value={formData.city}
                    onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="neighborhood">Barrio/Sector</Label>
                  <Input
                    id="neighborhood"
                    placeholder="El Poblado"
                    value={formData.neighborhood}
                    onChange={(e) => setFormData(prev => ({ ...prev, neighborhood: e.target.value }))}
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Características */}
          <div className="space-y-4">
            <h3 className="text-sm text-gray-700">Características</h3>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedrooms">Habitaciones</Label>
                <Select value={formData.bedrooms} onValueChange={(value) => setFormData(prev => ({ ...prev, bedrooms: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="0" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Estudio</SelectItem>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="4">4</SelectItem>
                    <SelectItem value="5+">5+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bathrooms">Baños</Label>
                <Select value={formData.bathrooms} onValueChange={(value) => setFormData(prev => ({ ...prev, bathrooms: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="1" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="1.5">1.5</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="2.5">2.5</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="3+">3+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="area">Área (m²)</Label>
                <Input
                  id="area"
                  type="number"
                  placeholder="80"
                  value={formData.area}
                  onChange={(e) => setFormData(prev => ({ ...prev, area: e.target.value }))}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Información financiera */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Información Financiera</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rentPrice">Precio de Alquiler Mensual</Label>
                <Input
                  id="rentPrice"
                  type="number"
                  placeholder="2500000"
                  value={formData.rentPrice}
                  onChange={(e) => setFormData(prev => ({ ...prev, rentPrice: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deposit">Depósito de Garantía</Label>
                <Input
                  id="deposit"
                  type="number"
                  placeholder="2500000"
                  value={formData.deposit}
                  onChange={(e) => setFormData(prev => ({ ...prev, deposit: e.target.value }))}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea
              id="description"
              placeholder="Describe características adicionales, amenidades, etc..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>

          <Separator />

          {/* Preview */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm mb-3">Vista Previa</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Nombre:</span>
                <span>{formData.name || "Sin nombre"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tipo:</span>
                <span>{formData.type || "No definido"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Estado:</span>
                <Badge variant="secondary" className="ml-2">
                  {formData.status === "available" && "Disponible"}
                  {formData.status === "occupied" && "Ocupado"}
                  {formData.status === "maintenance" && "Mantenimiento"}
                  {formData.status === "inactive" && "Inactivo"}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Alquiler:</span>
                <span className="font-medium">
                  {formData.rentPrice ? `$${Number(formData.rentPrice).toLocaleString()}` : "$0"}
                </span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="sm:order-1">
              Cancelar
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700 sm:order-2">
              <Building className="mr-2 h-4 w-4" />
              Agregar Propiedad
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}