import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { CreditCard, Receipt, DollarSign, Calendar, CheckCircle } from "lucide-react";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";

interface RegisterPaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RegisterPaymentModal({ open, onOpenChange }: RegisterPaymentModalProps) {
  const [formData, setFormData] = useState({
    invoice: "",
    tenant: "",
    amount: "",
    paymentMethod: "",
    transactionRef: "",
    paymentDate: "",
    bank: "",
    accountNumber: "",
    notes: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Registering payment:", formData);
    onOpenChange(false);
    // Reset form
    setFormData({
      invoice: "",
      tenant: "",
      amount: "",
      paymentMethod: "",
      transactionRef: "",
      paymentDate: "",
      bank: "",
      accountNumber: "",
      notes: ""
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="bg-orange-100 p-2 rounded-lg">
              <CreditCard className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <DialogTitle>Registrar Pago</DialogTitle>
              <DialogDescription>
                Marcar una factura como pagada y registrar los detalles del pago
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información de la factura */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Receipt className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Información de la Factura</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invoice">Factura</Label>
                <Select value={formData.invoice} onValueChange={(value) => setFormData(prev => ({ ...prev, invoice: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar factura" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fac-802">FAC-802 - $7.600.000</SelectItem>
                    <SelectItem value="cnt-001-698877">CNT-001-OCR-698877 - $4.423.243</SelectItem>
                    <SelectItem value="cnt-001-218968">CNT-001-OCR-218968 - $4.423.243</SelectItem>
                    <SelectItem value="cnt-001-001">CNT-001-001 - $5.600.000</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tenant">Inquilino</Label>
                <Input
                  id="tenant"
                  value="Ismael González"
                  disabled
                  className="bg-gray-50"
                />
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
              <div className="flex items-center space-x-2 mb-2">
                <Receipt className="h-4 w-4 text-blue-600" />
                <span className="text-sm text-blue-800">Factura Seleccionada</span>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Número:</span>
                  <span>FAC-802</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Monto Total:</span>
                  <span className="font-medium">$7.600.000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Período:</span>
                  <span>Enero 2025</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Estado:</span>
                  <Badge className="bg-yellow-100 text-yellow-700">Pendiente</Badge>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Detalles del pago */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Detalles del Pago</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Monto Recibido</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="7600000"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="paymentDate">Fecha de Pago</Label>
                <Input
                  id="paymentDate"
                  type="date"
                  value={formData.paymentDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentDate: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Método de Pago</Label>
              <Select value={formData.paymentMethod} onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar método" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="transfer">Transferencia Bancaria</SelectItem>
                  <SelectItem value="cash">Efectivo</SelectItem>
                  <SelectItem value="check">Cheque</SelectItem>
                  <SelectItem value="card">Tarjeta de Crédito/Débito</SelectItem>
                  <SelectItem value="pse">PSE</SelectItem>
                  <SelectItem value="nequi">Nequi</SelectItem>
                  <SelectItem value="daviplata">Daviplata</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(formData.paymentMethod === "transfer" || formData.paymentMethod === "check") && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bank">Banco</Label>
                  <Select value={formData.bank} onValueChange={(value) => setFormData(prev => ({ ...prev, bank: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar banco" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bancolombia">Bancolombia</SelectItem>
                      <SelectItem value="banco-bogota">Banco de Bogotá</SelectItem>
                      <SelectItem value="banco-popular">Banco Popular</SelectItem>
                      <SelectItem value="davivienda">Davivienda</SelectItem>
                      <SelectItem value="bbva">BBVA</SelectItem>
                      <SelectItem value="nequi">Nequi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="accountNumber">Número de Cuenta/Ref.</Label>
                  <Input
                    id="accountNumber"
                    placeholder="****1234"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, accountNumber: e.target.value }))}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="transactionRef">Referencia de Transacción</Label>
              <Input
                id="transactionRef"
                placeholder="TXN123456789"
                value={formData.transactionRef}
                onChange={(e) => setFormData(prev => ({ ...prev, transactionRef: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notas del Pago</Label>
              <Textarea
                id="notes"
                placeholder="Información adicional sobre el pago..."
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                rows={3}
              />
            </div>
          </div>

          <Separator />

          {/* Resumen */}
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <div className="flex items-center space-x-2 mb-3">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <h4 className="text-sm text-green-800">Resumen del Pago</h4>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Factura:</span>
                <span>{formData.invoice || "No seleccionada"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Monto Recibido:</span>
                <span className="font-medium">
                  {formData.amount ? `$${Number(formData.amount).toLocaleString()}` : "$0"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Método:</span>
                <span>{formData.paymentMethod || "No definido"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Fecha:</span>
                <span>{formData.paymentDate || "No definida"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Estado Final:</span>
                <Badge className="bg-green-100 text-green-700">Pagado</Badge>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="sm:order-1">
              Cancelar
            </Button>
            <Button type="submit" className="bg-orange-600 hover:bg-orange-700 sm:order-2">
              <CheckCircle className="mr-2 h-4 w-4" />
              Registrar Pago
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}