import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Calendar, CalendarDays, FileText, DollarSign, User } from "lucide-react";
import { Badge } from "../ui/badge";
import { Separator } from "../ui/separator";

interface CreateInvoiceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateInvoiceModal({ open, onOpenChange }: CreateInvoiceModalProps) {
  const [formData, setFormData] = useState({
    tenant: "",
    property: "",
    period: "",
    amount: "",
    dueDate: "",
    description: "",
    type: "rent"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aquí iría la lógica para crear la factura
    console.log("Creating invoice:", formData);
    onOpenChange(false);
    // Reset form
    setFormData({
      tenant: "",
      property: "",
      period: "",
      amount: "",
      dueDate: "",
      description: "",
      type: "rent"
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="bg-purple-100 p-2 rounded-lg">
              <FileText className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <DialogTitle>Nueva Factura</DialogTitle>
              <DialogDescription>
                Crear una nueva factura de alquiler para un inquilino
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información básica */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Información del Inquilino</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tenant">Inquilino</Label>
                <Select value={formData.tenant} onValueChange={(value) => setFormData(prev => ({ ...prev, tenant: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar inquilino" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ismael">Ismael González</SelectItem>
                    <SelectItem value="antonio">Antonio José</SelectItem>
                    <SelectItem value="maria">María Rodriguez</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="property">Propiedad</Label>
                <Select value={formData.property} onValueChange={(value) => setFormData(prev => ({ ...prev, property: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar propiedad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="apt101">Apartamento 101 - Zona Rosa</SelectItem>
                    <SelectItem value="apt202">Apartamento 202 - El Poblado</SelectItem>
                    <SelectItem value="house301">Casa 301 - Laureles</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          {/* Detalles de facturación */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-gray-500" />
              <h3 className="text-sm text-gray-700">Detalles de Facturación</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Factura</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rent">Alquiler Mensual</SelectItem>
                    <SelectItem value="utilities">Servicios Públicos</SelectItem>
                    <SelectItem value="maintenance">Mantenimiento</SelectItem>
                    <SelectItem value="other">Otros</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Monto Total</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="2,500,000"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                  className="text-right"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate">Fecha de Vencimiento</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="period">Período de Facturación</Label>
              <Input
                id="period"
                placeholder="Enero 2025"
                value={formData.period}
                onChange={(e) => setFormData(prev => ({ ...prev, period: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción Adicional</Label>
              <Textarea
                id="description"
                placeholder="Detalles adicionales de la factura..."
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>
          </div>

          <Separator />

          {/* Preview */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm mb-3">Vista Previa</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Inquilino:</span>
                <span>{formData.tenant || "No seleccionado"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Propiedad:</span>
                <span>{formData.property || "No seleccionada"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Monto:</span>
                <span className="font-medium">
                  {formData.amount ? `$${Number(formData.amount).toLocaleString()}` : "$0"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Vencimiento:</span>
                <span>{formData.dueDate || "No definido"}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="sm:order-1">
              Cancelar
            </Button>
            <Button type="submit" className="bg-purple-600 hover:bg-purple-700 sm:order-2">
              <FileText className="mr-2 h-4 w-4" />
              Crear Factura
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}