import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown, DollarSign, FileText, AlertTriangle, CheckCircle } from "lucide-react";

const stats = [
  {
    title: "Emitido Este Mes",
    value: "$ 22.346.486,02",
    change: "+12.5%",
    changeType: "positive",
    icon: DollarSign,
    description: "vs mes anterior"
  },
  {
    title: "Vencido",
    value: "$ 0",
    change: "0",
    changeType: "neutral",
    icon: AlertTriangle,
    description: "facturas vencidas"
  },
  {
    title: "Cobrado Este Mes",
    value: "$ 9.350.000",
    change: "+8.3%",
    changeType: "positive",
    icon: CheckCircle,
    description: "vs mes anterior"
  },
  {
    title: "% Recuperación",
    value: "41.8%",
    change: "-2.1%",
    changeType: "negative",
    icon: TrendingUp,
    description: "vs mes anterior"
  }
];

export function DashboardStats() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card key={index} className="relative overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm text-gray-600 leading-tight">
                {stat.title}
              </CardTitle>
              <div className="bg-purple-100 p-2 rounded-lg flex-shrink-0">
                <Icon className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl md:text-2xl mb-2 leading-tight">{stat.value}</div>
              <div className="flex items-center space-x-2 flex-wrap gap-1">
                {stat.changeType === "positive" && (
                  <Badge variant="secondary" className="bg-green-100 text-green-700 flex items-center text-xs">
                    <TrendingUp className="h-3 w-3 mr-1 flex-shrink-0" />
                    {stat.change}
                  </Badge>
                )}
                {stat.changeType === "negative" && (
                  <Badge variant="secondary" className="bg-red-100 text-red-700 flex items-center text-xs">
                    <TrendingDown className="h-3 w-3 mr-1 flex-shrink-0" />
                    {stat.change}
                  </Badge>
                )}
                {stat.changeType === "neutral" && (
                  <Badge variant="secondary" className="bg-gray-100 text-gray-700 text-xs">
                    {stat.change}
                  </Badge>
                )}
                <span className="text-xs text-gray-500 leading-tight">{stat.description}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}