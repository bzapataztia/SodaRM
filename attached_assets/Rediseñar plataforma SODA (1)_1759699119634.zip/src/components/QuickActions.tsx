import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { FileText, Users, Building, CreditCard } from "lucide-react";
import { CreateInvoiceModal } from "./modals/CreateInvoiceModal";
import { AddPropertyModal } from "./modals/AddPropertyModal";
import { AddTenantModal } from "./modals/AddTenantModal";
import { RegisterPaymentModal } from "./modals/RegisterPaymentModal";

const actions = [
  {
    id: "invoice",
    title: "Nueva Factura",
    description: "Crear factura de alquiler",
    icon: FileText,
    color: "bg-blue-500 hover:bg-blue-600"
  },
  {
    id: "property",
    title: "Agregar Propiedad",
    description: "Registrar nueva propiedad",
    icon: Building,
    color: "bg-green-500 hover:bg-green-600"
  },
  {
    id: "tenant",
    title: "Nuevo Inquilino",
    description: "Registrar nuevo contacto",
    icon: Users,
    color: "bg-purple-500 hover:bg-purple-600"
  },
  {
    id: "payment",
    title: "Registrar Pago",
    description: "Marcar pago recibido",
    icon: CreditCard,
    color: "bg-orange-500 hover:bg-orange-600"
  }
];

export function QuickActions() {
  const [openModals, setOpenModals] = useState({
    invoice: false,
    property: false,
    tenant: false,
    payment: false
  });

  const openModal = (modalId: string) => {
    setOpenModals(prev => ({ ...prev, [modalId]: true }));
  };

  const closeModal = (modalId: string) => {
    setOpenModals(prev => ({ ...prev, [modalId]: false }));
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
          <p className="text-sm text-gray-500">
            Tareas más frecuentes de tu día a día
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-2 gap-3 md:gap-4">
            {actions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  variant="outline"
                  className="h-auto p-3 md:p-4 flex flex-col items-center space-y-2 hover:shadow-md transition-shadow"
                  onClick={() => openModal(action.id)}
                >
                  <div className={`p-2 rounded-lg ${action.color} flex-shrink-0`}>
                    <Icon className="h-4 w-4 md:h-5 md:w-5 text-white" />
                  </div>
                  <div className="text-center">
                    <div className="text-sm leading-tight">{action.title}</div>
                    <div className="text-xs text-gray-500 leading-tight">{action.description}</div>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <CreateInvoiceModal 
        open={openModals.invoice} 
        onOpenChange={(open) => !open && closeModal("invoice")} 
      />
      <AddPropertyModal 
        open={openModals.property} 
        onOpenChange={(open) => !open && closeModal("property")} 
      />
      <AddTenantModal 
        open={openModals.tenant} 
        onOpenChange={(open) => !open && closeModal("tenant")} 
      />
      <RegisterPaymentModal 
        open={openModals.payment} 
        onOpenChange={(open) => !open && closeModal("payment")} 
      />
    </>
  );
}