
  # Rediseñar plataforma SODA

  This is a code bundle for Rediseñar plataforma SODA. The original project is available at https://www.figma.com/design/V9i76swoyI98sEhypxhAnb/Redise%C3%B1ar-plataforma-SODA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  